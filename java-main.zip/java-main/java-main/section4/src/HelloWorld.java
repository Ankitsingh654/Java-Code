public class HelloWorld {

    public static void main(String[] myArgs) {
        System.out.println("Hello World !!!");
    }

    public static void main(String[] myArgs, float num) {
        System.out.println("Hello World !!!");
    }

    public double main(){
        return 3.14;
    }

}
