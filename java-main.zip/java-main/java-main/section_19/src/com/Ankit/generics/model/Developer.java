package com.eazybytes.generics.model;

public class Developer extends Employee {

    @Override
    public String toString() {
        return "Developer{}";
    }
}
