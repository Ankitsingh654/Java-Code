package com.eazybytes.generics.model;

public class Manager extends Employee {

    @Override
    public String toString() {
        return "Manager{}";
    }
}
