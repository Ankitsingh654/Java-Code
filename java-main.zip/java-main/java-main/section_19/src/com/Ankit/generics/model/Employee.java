package com.eazybytes.generics.model;

public class Employee {

    @Override
    public String toString() {
        return "Employee{}";
    }
}
