public class SubStringDemo {

    public static void main(String[] args) {
        String originalString = "Hello, World!";
        String subString1 = originalString.substring(7);
        String subString2 = originalString.substring(0,5);
    }

}
