public class StringSplitDemo {

    public static void main(String[] args) {
        String fruits = "apple,orange,banana,grape";
        String[] fruitArray = fruits.split(",");
    }

}
