public class CharAtMethodDemo {

    public static void main(String[] args) {
        String java = "JAVA";
        char j = java.charAt(0);
        char exception = java.charAt(4);
    }

}
