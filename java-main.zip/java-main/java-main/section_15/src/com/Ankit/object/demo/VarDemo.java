package com.eazybytes.object.demo;

public class VarDemo {

    public static void main(String[] args) {
        var message = "Hello World !";
        var person = new Person();
        var arr = new ArrayIndexOutOfBoundsException();
    }

}
