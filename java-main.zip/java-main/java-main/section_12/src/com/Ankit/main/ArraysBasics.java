package com.eazybytes.main;

import com.eazybytes.model.Person;

public class ArraysBasics {

    public static void main(String[] args) {
        int mobileNumber1, mobileNumber2, mobileNumber3;

        int[] mobileNumbers = new int[5];
        mobileNumbers[0] = 766554433;
        mobileNumbers[1] = 566554433;
        mobileNumbers[2] = 567554433;
        mobileNumbers[3] = 766573233;
        mobileNumbers[4] = 766738433;
        // mobileNumbers[5] = 766732433;
        int[] nums = {1,2,3,4,5};
        int []mobileNums;

        double[] prices;
        char[] grades;
        String[] names;

        int length = 100;
        Person[] persons = new Person[length*2];
    }

}
