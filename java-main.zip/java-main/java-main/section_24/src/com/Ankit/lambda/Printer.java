package com.eazybytes.lambda;

@FunctionalInterface
public interface Printer {

    void print(String input);

}
