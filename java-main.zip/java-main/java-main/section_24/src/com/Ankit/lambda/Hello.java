package com.eazybytes.lambda;

@FunctionalInterface
public interface Hello {

     void sayHello();

}
