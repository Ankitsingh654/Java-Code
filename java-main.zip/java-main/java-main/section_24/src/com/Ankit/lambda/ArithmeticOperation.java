package com.eazybytes.lambda;

@FunctionalInterface
public interface ArithmeticOperation {

    int operation(int num1, int num2);

}
