package com.eazybytes.marvel.hero;

@FunctionalInterface
public interface MyFunctionalInterface {

    void myMethod();

}
