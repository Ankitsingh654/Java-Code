package com.eazybytes.marvel.hero.impl;

import com.eazybytes.marvel.hero.Person;

public class Developer extends Employee implements Person {

}
