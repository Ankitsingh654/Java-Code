package com.eazybytes.marvel.hero.impl;

import java.io.Serializable;

public class Employee implements Cloneable, Serializable {

    public void walk() {
        System.out.println("Employee Walking");
    }

}
