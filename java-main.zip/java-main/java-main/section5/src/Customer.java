/*
  This class represents a customer in Bank app.
  It contains information such as firstName,
  lastName, DOB, address and account details.
  */
public class Customer {
}
