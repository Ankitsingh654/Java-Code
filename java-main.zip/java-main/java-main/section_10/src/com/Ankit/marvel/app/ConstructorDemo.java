package com.eazybytes.marvel.app;

import com.eazybytes.marvel.base.Subject;
import com.eazybytes.marvel.vehicle.Car;

public class ConstructorDemo {

    public static void main(String[] args) {
        Car car = new Car();
        System.out.println(car.madeFor);
    }

}
