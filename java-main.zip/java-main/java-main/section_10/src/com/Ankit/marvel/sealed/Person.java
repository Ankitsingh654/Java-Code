package com.eazybytes.marvel.sealed;

public sealed class Person permits Student, Employee {
}
