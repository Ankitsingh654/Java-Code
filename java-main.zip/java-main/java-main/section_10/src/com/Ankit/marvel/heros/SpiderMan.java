package com.eazybytes.marvel.heros;

import com.eazybytes.marvel.base.Person;

public class SpiderMan extends Person {

    public void usePower() {
        System.out.println("SpiderMan is using his power");
    }

}
