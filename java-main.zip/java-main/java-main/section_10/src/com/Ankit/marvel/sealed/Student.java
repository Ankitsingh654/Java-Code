package com.eazybytes.marvel.sealed;

public final class Student extends Person {
}
