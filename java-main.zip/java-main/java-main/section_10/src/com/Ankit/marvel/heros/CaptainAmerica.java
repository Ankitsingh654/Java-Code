package com.eazybytes.marvel.heros;

import com.eazybytes.marvel.base.Person;

public class CaptainAmerica extends Person {

    public void usePower() {
        System.out.println("Captain America is using his power");
    }

}
