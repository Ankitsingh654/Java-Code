package com.eazybytes.marvel.app;

import com.eazybytes.marvel.heros.IronMan;

public class StaticPoly {

    public static void main(String[] args) {

        IronMan ironMan = new IronMan();
        ironMan.eat("Pasta");
        ironMan.eat("Pasta", 1);

    }

}
