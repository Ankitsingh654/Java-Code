package com.eazybytes.marvel.subjects;

import com.eazybytes.marvel.base.Subject;

public class Mathematics extends Subject {

    @Override
    public void teach() {
        System.out.println("I am trying to teach mathematics");
    }

}
