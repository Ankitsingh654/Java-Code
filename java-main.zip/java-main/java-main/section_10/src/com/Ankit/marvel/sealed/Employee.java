package com.eazybytes.marvel.sealed;

public non-sealed class Employee extends Person {
}
