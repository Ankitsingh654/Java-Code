public class DoWhileStatementDemo {

    public static void main(String[] args) {

        int n = 6;

        do {
            System.out.println(n);
            n++;
        } while ( n < 10);

    }

}
