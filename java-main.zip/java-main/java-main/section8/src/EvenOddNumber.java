public class EvenOddNumber {

    public static void main(String[] args) {
       int inputNumber = 9;

       if (inputNumber%2 == 0) {
           System.out.println("The given number is even");
       } else {
           System.out.println("The given number is odd");
       }

    }

}
