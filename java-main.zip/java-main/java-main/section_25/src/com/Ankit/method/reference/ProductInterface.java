package com.eazybytes.method.reference;

@FunctionalInterface
public interface ProductInterface {

    Product getProduct(String name, int price);

}
