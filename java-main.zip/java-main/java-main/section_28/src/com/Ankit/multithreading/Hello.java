package com.eazybytes.multithreading;

public class Hello {

    public static void sayHello() {
        System.out.println("Hello from Method Reference approach");
    }

}
