package com.eazybytes.exception;

public class UnCheckedExceptionsDemo {

    public static void main(String[] args) {
        String input = null;
            input = "Madan";
            input = input.toUpperCase();
            input = input.substring(1,10);
    }

}
