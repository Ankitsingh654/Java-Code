package com.eazybytes.service;

public class VehicleService {
}
