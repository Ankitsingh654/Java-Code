package com.eazybytes.model;

public class Class1 {
}
