package com.eazybytes.model;

public class Vehicle {
}
