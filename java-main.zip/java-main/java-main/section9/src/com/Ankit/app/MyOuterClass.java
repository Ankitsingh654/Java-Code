package com.eazybytes.app;

public class MyOuterClass {

      static class MyInnerClass {
        public void display() {
            System.out.println("Hello from Inner class");
        }
    }

}
