package com.eazybytes.legacy;

import java.util.Date;

public class LegacyDateAPIDemo {

    public static void main(String[] args) {
        Date date = new Date();
        Date date1 = new Date(200, 8, 26);
        System.out.println(date1);
    }

}
