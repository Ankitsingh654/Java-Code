package com.eazybytes.list;

import java.util.ArrayList;
import java.util.List;

public class DiamondOperator {

    public static void main(String[] args) {
        // DRY - Don't REPEAT Yourself
        ArrayList<Integer> nums = new ArrayList<>();
        List<Character> characters = new ArrayList<>();
        var doubleNums = new ArrayList<Double>();
        List<String> countryNames = new ArrayList<>();
    }

}
