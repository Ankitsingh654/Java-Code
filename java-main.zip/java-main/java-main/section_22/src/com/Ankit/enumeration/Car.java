package com.eazybytes.enumeration;

public class Car {
    public enum Model {
        SEDAN, SUV, HATCHBACK
    }
}
