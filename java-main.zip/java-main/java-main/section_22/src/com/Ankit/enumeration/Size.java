package com.eazybytes.enumeration;

public enum Size {
    SMALL, MEDIUM, LARGE, EXTRA_LARGE
}
