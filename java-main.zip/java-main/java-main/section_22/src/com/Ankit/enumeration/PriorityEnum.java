package com.eazybytes.enumeration;

public enum PriorityEnum {
    LOW, MEDIUM, HIGH, URGENT
}
