package com.eazybytes.enumeration;

public enum Grades {

    A, B, C, D, E

}
